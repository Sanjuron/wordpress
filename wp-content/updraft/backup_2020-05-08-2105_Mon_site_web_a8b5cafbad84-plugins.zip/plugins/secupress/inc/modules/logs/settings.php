<?php
defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );

$this->load_plugin_settings( 'banned-ips' );
$this->load_plugin_settings( 'logs' );
